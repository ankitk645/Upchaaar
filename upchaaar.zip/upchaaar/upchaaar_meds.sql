-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2017 at 03:35 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `upchaaar_meds`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `image` varchar(300) NOT NULL,
  `serivce_item_1` varchar(100) NOT NULL,
  `serivce_item_2` varchar(100) NOT NULL,
  `serivce_item_3` varchar(100) NOT NULL,
  `serivce_item_4` varchar(100) NOT NULL,
  `serivce_item_5` varchar(100) NOT NULL,
  `serivce_item_6` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `description`, `image`, `serivce_item_1`, `serivce_item_2`, `serivce_item_3`, `serivce_item_4`, `serivce_item_5`, `serivce_item_6`) VALUES
(1, 'About Us Goes here.....', 'images/slide3.png', 'Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5', 'Item 6');

-- --------------------------------------------------------

--
-- Table structure for table `amazing_team`
--

CREATE TABLE `amazing_team` (
  `id` int(11) NOT NULL,
  `image` varchar(300) NOT NULL,
  `name` varchar(50) NOT NULL,
  `post` varchar(50) NOT NULL,
  `social_fb` varchar(100) NOT NULL,
  `social_twt` varchar(100) NOT NULL,
  `social_ggl` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `amazing_team`
--

INSERT INTO `amazing_team` (`id`, `image`, `name`, `post`, `social_fb`, `social_twt`, `social_ggl`) VALUES
(1, 'images/34.jpg', 'Person 1', 'CEO', 'http://fb.com', 'http://twitter.com', 'http://google.com/plus'),
(2, 'images/33.jpg', 'Person 2', 'Web Developer', 'http://fb.com', 'http://twitter.com', 'http://google.com/plus'),
(3, 'images/32.jpg', 'Person 3', 'CFO', 'http://fb.com', 'http://twitter.com', 'http://google.com/plus'),
(4, 'images/35.jpg', 'Person 4', 'COO', 'http://fb.com', 'http://twitter.com', 'http://google.com/plus');

-- --------------------------------------------------------

--
-- Table structure for table `basics`
--

CREATE TABLE `basics` (
  `id` int(11) NOT NULL,
  `site_name` varchar(50) NOT NULL,
  `site_2name` varchar(30) NOT NULL,
  `offer_txt` varchar(100) NOT NULL,
  `contact_nu` varchar(20) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `logo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `basics`
--

INSERT INTO `basics` (`id`, `site_name`, `site_2name`, `offer_txt`, `contact_nu`, `email_id`, `logo`) VALUES
(2, '.com', 'Upchaaar', 'Today''s Special Offer', '(+91) - 000 00000 00', 'store@netmeds.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `c_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `item_quantity` int(10) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `item_category` varchar(20) NOT NULL,
  `item_prescription` varchar(10) NOT NULL,
  `item_normal_price` int(10) NOT NULL,
  `item_offer_price` int(10) NOT NULL,
  `item_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `c_id`, `product_id`, `item_quantity`, `item_name`, `item_category`, `item_prescription`, `item_normal_price`, `item_offer_price`, `item_image`) VALUES
(23, 20, 2, 2, 'Senior Care and Aids', 'scaa', 'no', 260, 256, 'images/products/dove.jpg'),
(25, 20, 10, 1, 'Baby and Mother', 'bam', 'no', 300, 300, 'images/products/dove.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `topic1` varchar(150) NOT NULL,
  `desc1` longtext NOT NULL,
  `topic2` varchar(150) NOT NULL,
  `desc2` longtext NOT NULL,
  `topic3` varchar(150) NOT NULL,
  `desc3` longtext NOT NULL,
  `topic4` varchar(150) NOT NULL,
  `desc4` longtext NOT NULL,
  `topic5` varchar(150) NOT NULL,
  `desc5` longtext NOT NULL,
  `topic6` varchar(150) NOT NULL,
  `desc6` longtext NOT NULL,
  `topic7` varchar(150) NOT NULL,
  `desc7` longtext NOT NULL,
  `topic8` varchar(150) NOT NULL,
  `desc8` longtext NOT NULL,
  `topic9` varchar(150) NOT NULL,
  `desc9` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `topic1`, `desc1`, `topic2`, `desc2`, `topic3`, `desc3`, `topic4`, `desc4`, `topic5`, `desc5`, `topic6`, `desc6`, `topic7`, `desc7`, `topic8`, `desc8`, `topic9`, `desc9`) VALUES
(5, 'Topic 1', 'Description 1', 'Topic 2', 'Description 2', 'Topic 3', 'Description 3', 'Topic 4', 'Description 4', 'Topic 5', 'Description 5', 'Topic 6', 'Description 6', 'Topic 7', 'Description 7', 'Topic 8', 'Description 8', 'Topic 9', 'Description 9');

-- --------------------------------------------------------

--
-- Table structure for table `home_banners`
--

CREATE TABLE `home_banners` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `banner` varchar(300) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home_banners`
--

INSERT INTO `home_banners` (`id`, `name`, `banner`, `text`) VALUES
(1, 'slide_banner1', 'images/1.jpg', 'Buy Medicine');

-- --------------------------------------------------------

--
-- Table structure for table `privacy`
--

CREATE TABLE `privacy` (
  `id` int(11) NOT NULL,
  `profile_desc` longtext NOT NULL,
  `search_desc` longtext NOT NULL,
  `ms_desc` longtext NOT NULL,
  `delivery_desc` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `privacy`
--

INSERT INTO `privacy` (`id`, `profile_desc`, `search_desc`, `ms_desc`, `delivery_desc`) VALUES
(1, 'tyjytjyt', 'yjtyj', 'tyjtyj', 'tyjtj'),
(2, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `category` varchar(100) NOT NULL,
  `prescription` text NOT NULL,
  `date_added` date NOT NULL,
  `expiry_date` date NOT NULL,
  `normal_price` varchar(20) NOT NULL,
  `offer_price` varchar(20) NOT NULL,
  `discount` int(11) NOT NULL,
  `image` varchar(300) NOT NULL,
  `desscription` longtext NOT NULL,
  `flag` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `prescription`, `date_added`, `expiry_date`, `normal_price`, `offer_price`, `discount`, `image`, `desscription`, `flag`) VALUES
(1, 'Ortho Support', 'os', 'no', '2017-06-07', '2017-09-16', '260', '256', 4, 'images/products/dove.jpg', 'About this product', 'lates_added'),
(2, 'Senior Care and Aids', 'scaa', 'no', '0000-00-00', '0000-00-00', '260', '256', 4, 'images/products/dove.jpg', 'About this product', 'lates_added'),
(3, 'OTC', 'otc', 'no', '0000-00-00', '0000-00-00', '321', '250', 56, 'images/products/dove.jpg', '', 'lates_added'),
(4, 'Maternity and Mother Care', 'mamc', 'no', '2017-06-07', '2017-09-15', '212', '100', 0, 'images/products/dove.jpg', 'Lol', 'lates_added'),
(5, 'Personal Care', 'pc', 'no', '2017-06-14', '2017-06-30', '200', '200', 0, 'images/products/dove.jpg', 'ABC', 'lates_added'),
(6, 'Skin Diseases', 'sd', 'yes', '2017-06-14', '2017-06-30', '200', '200', 0, 'images/products/dove.jpg', 'ABC', 'lates_added'),
(7, 'P Drugs', 'pd', 'yes', '2017-06-14', '2017-06-30', '200', '200', 0, 'images/products/dove.jpg', 'ABC', 'lates_added'),
(8, 'Osteoporosis', 'osteo', 'yes', '2017-06-14', '2017-06-30', '200', '200', 0, 'images/products/dove.jpg', 'ABC', 'lates_added'),
(9, 'Health Aid', 'ha', 'no', '2017-06-14', '2017-06-30', '200', '200', 0, 'images/products/dove.jpg', 'ABC', 'lates_added'),
(10, 'Baby and Mother', 'bam', 'no', '2017-06-16', '2017-06-24', '300', '300', 0, 'images/products/dove.jpg', 'About', 'lates_added'),
(11, 'Wellness', 'wellness', 'no', '2017-06-16', '2017-06-24', '300', '300', 0, 'images/products/dove.jpg', 'About', 'lates_added'),
(12, 'Men Care', 'men_care', 'no', '2017-06-16', '2017-06-24', '300', '300', 0, 'images/products/dove.jpg', 'About', 'lates_added'),
(13, 'Women Care', 'women_care', 'no', '2017-06-16', '2017-06-24', '300', '300', 0, 'images/products/dove.jpg', 'About', '');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `description`, `name`) VALUES
(1, 'Good', 'Vikas'),
(2, ' Bad', 'Ankit');

-- --------------------------------------------------------

--
-- Table structure for table `top_prdtc_banners`
--

CREATE TABLE `top_prdtc_banners` (
  `banner1_long` varchar(300) NOT NULL,
  `banner2_short` varchar(300) NOT NULL,
  `banner3_short` varchar(300) NOT NULL,
  `banner4_short` varchar(300) NOT NULL,
  `banner5_short` varchar(300) NOT NULL,
  `offer_line` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tos`
--

CREATE TABLE `tos` (
  `id` int(11) NOT NULL,
  `topic` varchar(200) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tos`
--

INSERT INTO `tos` (`id`, `topic`, `description`) VALUES
(1, '1. ABCD', 'ABCD'),
(2, '2. EFGH', 'EFGH'),
(3, '3. HIJK', 'HIJK'),
(4, '4. LMNO', 'LMNO');

-- --------------------------------------------------------

--
-- Table structure for table `twitter_posts`
--

CREATE TABLE `twitter_posts` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `tweet` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `twitter_posts`
--

INSERT INTO `twitter_posts` (`id`, `date`, `tweet`) VALUES
(1, '2017-02-20', 'Hey, this is test....'),
(2, '2017-02-12', 'Hey, this is new test...');

-- --------------------------------------------------------

--
-- Table structure for table `usersdata`
--

CREATE TABLE `usersdata` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `country` varchar(40) NOT NULL,
  `address` longtext NOT NULL,
  `landmark` varchar(20) NOT NULL,
  `pin` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usersdata`
--

INSERT INTO `usersdata` (`id`, `email`, `password`, `name`, `mobile`, `city`, `state`, `country`, `address`, `landmark`, `pin`) VALUES
(3, 'ankitkumarsingh645@gmail.com', 'ankitk645', 'Ankit Kumar', '6200853341', 'Arrah', 'Bihar', 'India', 'Krishna nagar', 'Near station', 802301);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `amazing_team`
--
ALTER TABLE `amazing_team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `basics`
--
ALTER TABLE `basics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_banners`
--
ALTER TABLE `home_banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `privacy`
--
ALTER TABLE `privacy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tos`
--
ALTER TABLE `tos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `twitter_posts`
--
ALTER TABLE `twitter_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usersdata`
--
ALTER TABLE `usersdata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `amazing_team`
--
ALTER TABLE `amazing_team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `basics`
--
ALTER TABLE `basics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `home_banners`
--
ALTER TABLE `home_banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `privacy`
--
ALTER TABLE `privacy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tos`
--
ALTER TABLE `tos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `twitter_posts`
--
ALTER TABLE `twitter_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `usersdata`
--
ALTER TABLE `usersdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
